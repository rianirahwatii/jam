package com.example.aplikasi_jam_digital_rianiindah;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;

import android.widget.LinearLayout;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    LinearLayout format, date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        format = findViewById(R.id.format);
        date = findViewById(R.id.date);

        format.setOnClickListener(this::onClick);

    }

    private void onClick(View v) {
        Intent MainActivity = new Intent(getApplicationContext(), com.example.aplikasi_jam_digital_rianiindah.MainActivity.class);
        startActivity(MainActivity);
    }
}